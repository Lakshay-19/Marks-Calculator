﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

//Lakshay Punj
//April 25, 2019 
//Program to open files, 

namespace Marks
{
    public partial class Form1 : Form
    {
       //Global variables

        double[] Marks;
        
        
        public Form1()
        {
            InitializeComponent();
        }

        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //Open file dialogue
            OpenFileDialog fd = new OpenFileDialog();

            if (fd.ShowDialog() == DialogResult.OK)
            {
                //Create stream reader to open
                //and read file

                StreamReader sr = new StreamReader(fd.OpenFile());
                //Get number of marks to read in

                int Records = int.Parse(sr.ReadLine());

                //Size of marks array
                Marks = new double[Records];
                //Store values from file into array

                for (int i=0; i < Records; i++)
                {
                    Marks[i] = double.Parse(sr.ReadLine());
                }

                mnuFileDisplay.Enabled = true;
                mnuFileAverage.Enabled = true;

                lblMsg.Text = "File loaded successfully";
            }
            

            else
            {
                mnuFileDisplay.Enabled = false;
                mnuFileAverage.Enabled = false;

                lblMsg.Text = "No file loaded";
            }





        }

        private void mnuFileDisplay_Click(object sender, EventArgs e)
        {
            string Output = string.Empty;
            //Loop through array

            for (int i=0; i < Marks.Length; i++)
            {
                Output = Output + Marks[i] + "/n";
            }

            lblDisplay.Text = Output; 





        }

        private void mnuFileAverage_Click(object sender, EventArgs e)
        {
            double Sum = 0;

            for (int i=0; i < Marks.Length; i++)
            {
                Sum += Marks[i];
            }

            double Average = Sum / Marks.Length;
            lblAverage.Text = "Average = " + Average;


       }


    }
}
